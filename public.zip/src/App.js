import React from 'react';
import './App.css';
import Tetris from './components/Tetris';

const App = () => {
  return (
    <div className='App'>
      <header></header>
      <Tetris />
    </div>
  );
};

export default App;
