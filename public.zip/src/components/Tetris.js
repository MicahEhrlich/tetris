import React from 'react';
import Level from '../components/Level';

const Tetris = () => {
  const level = Array.from(Array(20), () => new Array(10).fill(['black']));
  return (
    <div>
      <Level level={level} />
    </div>
  );
};

export default Tetris;
