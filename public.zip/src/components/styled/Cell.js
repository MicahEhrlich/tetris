import styled from 'styled-components';

const Cell = styled.div`
  width: 40px;
  height: 40px;
  border: 2px solid;
  border-bottom-color: red;
  border-right-color: red;
  background: ${(props) => props.backgroud};
`;
export default Cell;
