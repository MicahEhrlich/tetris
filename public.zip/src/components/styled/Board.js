import styled from 'styled-components';

const Board = styled.div`
  display: grid;
  grid-template-rows: repeat(80, minmax(1em, 1fr));
  grid-template-columns: repeat(10, minmax(1em, 3em));
  background: black;
`;
export default Board;
