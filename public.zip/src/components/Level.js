import React, { useState } from 'react';
import Cell from '../components/styled/Cell';
import Board from './styled/Board';

const Level = ({ level }) => {
  const [stage, setStage] = useState(level);
  const [pos, setPos] = useState([
    [0, 0],
    [0, 1],
  ]);

  const updateLevel = (pos) => {
    for (let i = 0; i < level.length; i++)
      for (let j = 0; j < level[0].length; j++) level[i][j] = ['black'];

    let newStage = level;

    newStage[pos[0][0]][pos[0][1]] = ['darkblue'];
    newStage[pos[1][0]][pos[1][1]] = ['darkblue'];

    setStage(newStage);
    setPos(pos);
  };

  const moveShape = ({ keyCode }) => {
    if (keyCode === 38) {
      let tempPos = [
        [pos[0][0] - 1, pos[0][1]],
        [pos[1][0] - 1, pos[1][1]],
      ];
      updateLevel(tempPos);

      // up arrow
    } else if (keyCode === 40) {
      // down arrow
      let tempPos = [
        [pos[0][0] + 1, pos[0][1]],
        [pos[1][0] + 1, pos[1][1]],
      ];
      updateLevel(tempPos);
    } else if (keyCode === 37) {
      // left arrow
      let tempPos = [
        [pos[0][0], pos[0][1] - 1],
        [pos[1][0], pos[1][1] - 1],
      ];
      updateLevel(tempPos);
    } else if (keyCode === 39) {
      // right arrow
      let tempPos = [
        [pos[0][0], pos[0][1] + 1],
        [pos[1][0], pos[1][1] + 1],
      ];
      updateLevel(tempPos);
    }

    console.log(pos);
  };

  return (
    <Board role='button' tabIndex='0' onKeyDown={(e) => moveShape(e)}>
      {stage.map((row) =>
        row.map((cell, x) => <Cell key={x} backgroud={cell} />)
      )}
    </Board>
  );
};

export default Level;
